package com.bmpl.streetfighter.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.bmpl.streetfighter.utils.GameConstants;

public class Hulk extends CommonPlayer implements GameConstants {
	
	private BufferedImage idleFrames[] = new BufferedImage[6];
	private BufferedImage walkFrames[] = new BufferedImage[6];
	
	public Hulk() {
		x = 200;
		h = 350;
		w = 300;
		y = GROUND - h;
		speed = SPEED;
		imageIndex = 0;
		loadPlayerImage();
		loadIdleImage();
		loadWalkImages();
	}
	
	private void loadIdleImage() {
		idleFrames[0] = img.getSubimage(35, 36, 60, 86);
		idleFrames[1] = img.getSubimage(422, 167, 55, 84);
		idleFrames[2] = img.getSubimage(552, 167, 59, 84);
		idleFrames[3] = img.getSubimage(677, 181, 57, 70);
		idleFrames[4] = img.getSubimage(803, 181, 58, 70);
		idleFrames[5] = img.getSubimage(934, 171, 58, 80);	
	}
	
	private void loadWalkImages() {
		walkFrames[0] = img.getSubimage(144, 36, 89, 86);
		walkFrames[1] = img.getSubimage(299, 36, 53, 86);
		walkFrames[2] = img.getSubimage(421, 36, 56, 86);
		walkFrames[3] = img.getSubimage(534, 36, 91, 86);
		walkFrames[4] = img.getSubimage(665, 36, 89, 86);
		walkFrames[5] = img.getSubimage(810, 36, 52, 86);
	}
	
	private BufferedImage showWalk() {
		if(imageIndex > walkFrames.length-1) {
			imageIndex = 0;
			currentMove = IDLE;
		}
		BufferedImage img = walkFrames[imageIndex];
		imageIndex++;
		return img;
	}
	
	private BufferedImage showIdle() {
		if(imageIndex > idleFrames.length-1) {
			imageIndex = 0;
		}
		BufferedImage img = idleFrames[imageIndex];
		imageIndex++;
		return img;
	}
	
	@Override
	public BufferedImage defaultImage() {
		if(currentMove == WALK) {
			return showWalk();
		}
		else {
			return showIdle();
		}
	}
	
	
	private void loadPlayerImage() {
		try {
			img = ImageIO.read(Hulk.class.getResource(HULK_IMG));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
