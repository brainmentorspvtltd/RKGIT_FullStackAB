package com.bmpl.streetfighter.utils;

public interface GameConstants {
	String TITLE = "Street Fighter By Brain Mentors";
	int SCREENWIDTH = 1800;
	int SCREENHEIGHT = 1000;
	int GROUND = SCREENHEIGHT - 100;
	int SPEED = 10;
	String HULK_IMG = "hulk.png";
	String THOR_IMG = "thor_flip.png";
}
