package com.bmpl.streetfighter.sprites;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.bmpl.streetfighter.utils.GameConstants;

public class Hulk extends CommonPlayer implements GameConstants {
	
	public Hulk() {
		x = 200;
		h = 350;
		w = 300;
		y = GROUND - h;
		speed = SPEED;
		loadPlayerImage();
	}
	
	private BufferedImage loadIdleImage() {
		return img.getSubimage(35, 36, 60, 86);
	}
	
	@Override
	public BufferedImage defaultImage() {
		return loadIdleImage();
	}
	
	
	private void loadPlayerImage() {
		try {
			img = ImageIO.read(Hulk.class.getResource(HULK_IMG));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
