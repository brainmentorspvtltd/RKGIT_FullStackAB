package com.bmpl.streetfighter.utils;

public interface GameConstants {
	String TITLE = "Street Fighter By Brain Mentors";
	int SCREENWIDTH = 1500;
	int SCREENHEIGHT = 800;
}
