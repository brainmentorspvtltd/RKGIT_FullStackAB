package com.bmpl.streetfighter.views;

import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import com.bmpl.streetfighter.utils.GameConstants;

public class GameBoard extends JPanel implements GameConstants {
	BufferedImage bgImage;
	public GameBoard() {
		loadBackground();
	}
	
	@Override
	protected void paintComponent(Graphics pen) {
		paintBackground(pen);
	}
	
	private void paintBackground(Graphics pen) {
		pen.drawImage(bgImage, 0, 0, SCREENWIDTH, SCREENHEIGHT, null);
	}
	
	private void loadBackground() {
		try {
			bgImage = ImageIO.read(GameBoard.class.getResource("bg_1.jpg"));
		} catch (IOException e) {
			JOptionPane.showMessageDialog(this, "Something went wrong...");
			System.out.println("Failed to load background image...");
			System.exit(0);
			
		}
	}
}
