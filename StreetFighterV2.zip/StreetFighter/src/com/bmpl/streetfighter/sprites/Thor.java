package com.bmpl.streetfighter.sprites;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

import com.bmpl.streetfighter.utils.GameConstants;

public class Thor extends CommonPlayer implements GameConstants {
	
	public Thor() {
		x = SCREENWIDTH - 500;
		h = 350;
		w = 300;
		y = GROUND - h;
		speed = SPEED;
		loadPlayerImage();
	}
	
	private BufferedImage loadIdleImage() {
		return img.getSubimage(3399, 55, 140, 146);
	}
	
	@Override
	public BufferedImage defaultImage() {
		return loadIdleImage();
	}
	
	
	private void loadPlayerImage() {
		try {
			img = ImageIO.read(Thor.class.getResource(THOR_IMG));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
